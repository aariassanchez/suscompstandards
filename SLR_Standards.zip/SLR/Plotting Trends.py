import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
#Skeleton code and debugging by Copilot

#Data to be read
df = pd.read_excel('Combinded.xlsx')
accepted = df.copy()

#Data Cleaning
accepted['Year_Clean'] = pd.to_numeric(accepted['Year'], errors='coerce')
accepted.loc[accepted['Year'] == 'Draft/Undated', 'Year_Clean'] = 2026
accepted = accepted.dropna(subset=['Year_Clean'])
accepted['Year_Clean'] = accepted['Year_Clean'].astype(int)

yearly_counts = accepted.groupby('Year_Clean').size().reset_index(name='Count')

yearly_counts['Cumulative_Count'] = yearly_counts['Count'].cumsum()

# Line Graph
plt.figure(figsize=(10, 6))
sns.lineplot(data=yearly_counts, x='Year_Clean', y='Cumulative_Count', marker='o', color='teal', linewidth=2)
plt.title('Standardization Trend Over Time (Line Graph)')
plt.xlabel('Year')
plt.ylabel('Number of Papers')
plt.grid(True, linestyle='--', alpha=0.6)
plt.savefig('line_trend.png')

# Bubble Chart
plt.figure(figsize=(12, 8))
bubble_data = accepted.groupby(['Year_Clean', 'Lifecycle Domain']).size().reset_index(name='Count')
sns.scatterplot(data=bubble_data, x='Year_Clean', y='Lifecycle Domain', size='Count', hue='Lifecycle Domain', 
                sizes=(100, 2000), alpha=0.7, legend='brief')
plt.title('Topic Evolution over Years (Bubble Chart)')
plt.xlabel('Year')
plt.ylabel('Lifecycle Domain')
plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
plt.tight_layout()
plt.savefig('bubble_trend.png')

#Area Chart
plt.figure(figsize=(10, 6))
plt.fill_between(yearly_counts['Year_Clean'], yearly_counts['Count'], color="skyblue", alpha=0.4)
plt.plot(yearly_counts['Year_Clean'], yearly_counts['Count'], color="Slateblue", alpha=0.6, linewidth=2)
plt.title('Standardization Volume Over Time (Area Chart)')
plt.xlabel('Year')
plt.ylabel('Lifecycle Domain')
plt.savefig('area_trend.png')